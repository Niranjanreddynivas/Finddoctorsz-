import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Stethoscope, 
  Calendar, 
  Pills, 
  Video,
  Download,
  ArrowRight
} from 'lucide-react';

export default function Home() {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div className="space-y-8">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Your Health Journey Starts Here
              </h1>
              <p className="text-xl text-blue-100">
                Find and book appointments with the best doctors in Anantapur. Quality healthcare is just a click away.
              </p>
              <div className="space-x-4">
                <Link
                  to="/doctors"
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50"
                >
                  Find a Doctor
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </div>
            <div className="mt-12 lg:mt-0">
              <img
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80"
                alt="Doctor with patient"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 bg-white rounded-lg shadow-md">
            <Calendar className="h-12 w-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Easy Appointments</h3>
            <p className="text-gray-600">Book appointments with top doctors instantly</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <Pills className="h-12 w-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">E-Pharmacy</h3>
            <p className="text-gray-600">Coming soon: Order medicines online</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-md">
            <Video className="h-12 w-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Telemedicine</h3>
            <p className="text-gray-600">Coming soon: Virtual consultations</p>
          </div>
        </div>
      </section>

      {/* App Download Section */}
      <section className="bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Get the Finddoctorsz App</h2>
            <p className="text-gray-600 mb-8">Book appointments on the go with our mobile app</p>
            <div className="flex justify-center space-x-4">
              <button className="flex items-center px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800">
                <Download className="h-6 w-6 mr-2" />
                Google Play
              </button>
              <button className="flex items-center px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800">
                <Download className="h-6 w-6 mr-2" />
                App Store
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}