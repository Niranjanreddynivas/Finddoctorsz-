import React from 'react';
import { Heart, Shield, Users } from 'lucide-react';

export default function About() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">About Finddoctorsz</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Revolutionizing healthcare access in Anantapur through technology and innovation
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
          <p className="text-gray-600 mb-4">
            Founded with a vision to transform healthcare accessibility in Anantapur, Finddoctorsz 
            bridges the gap between patients and quality healthcare services through innovative 
            technology solutions.
          </p>
          <p className="text-gray-600">
            We understand the challenges faced by our community in accessing timely medical care, 
            and we're here to make that process seamless and efficient.
          </p>
        </div>
        <div>
          <img
            src="https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80"
            alt="Medical team"
            className="rounded-lg shadow-xl"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-12 mb-16">
        <div className="bg-blue-50 p-8 rounded-lg">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h2>
          <div className="flex items-start">
            <Heart className="h-8 w-8 text-blue-600 mr-4 flex-shrink-0" />
            <p className="text-gray-600">
              Making quality healthcare accessible to everyone in Anantapur and beyond, 
              especially in underserved areas, through innovative technology solutions.
            </p>
          </div>
        </div>
        <div className="bg-blue-50 p-8 rounded-lg">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <div className="flex items-start">
            <Users className="h-8 w-8 text-blue-600 mr-4 flex-shrink-0" />
            <p className="text-gray-600">
              To revolutionize healthcare delivery by connecting patients with the right healthcare 
              providers through a seamless, technology-driven platform.
            </p>
          </div>
        </div>
      </div>

      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Commitment</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6">
            <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Data Security</h3>
            <p className="text-gray-600">
              Your health information is protected with industry-leading security measures
            </p>
          </div>
          <div className="p-6">
            <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Patient First</h3>
            <p className="text-gray-600">
              Every feature and service is designed with patient needs in mind
            </p>
          </div>
          <div className="p-6">
            <Heart className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Quality Care</h3>
            <p className="text-gray-600">
              We partner with verified and qualified healthcare providers
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}