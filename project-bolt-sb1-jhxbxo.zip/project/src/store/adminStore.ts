import create from 'zustand';
import { Doctor } from '../types/doctor';

interface AdminStore {
  doctors: Doctor[];
  addDoctor: (doctor: Doctor) => void;
  updateDoctor: (id: string, doctor: Doctor) => void;
  deleteDoctor: (id: string) => void;
}

export const useAdminStore = create<AdminStore>((set) => ({
  doctors: [],
  addDoctor: (doctor) =>
    set((state) => ({ doctors: [...state.doctors, doctor] })),
  updateDoctor: (id, updatedDoctor) =>
    set((state) => ({
      doctors: state.doctors.map((doc) =>
        doc.id === id ? updatedDoctor : doc
      ),
    })),
  deleteDoctor: (id) =>
    set((state) => ({
      doctors: state.doctors.filter((doc) => doc.id !== id),
    })),
}));