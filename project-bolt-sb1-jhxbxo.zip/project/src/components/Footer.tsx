import React from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="flex items-center">
              <Stethoscope className="h-8 w-8 text-blue-500" />
              <span className="ml-2 text-xl font-bold text-white">Finddoctorsz</span>
            </Link>
            <p className="mt-4">Making quality healthcare accessible in Anantapur</p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/doctors" className="hover:text-blue-500">Find Doctors</Link></li>
              <li><Link to="/contact" className="hover:text-blue-500">Contact Us</Link></li>
              <li><Link to="/terms" className="hover:text-blue-500">Terms & Conditions</Link></li>
              <li><Link to="/privacy" className="hover:text-blue-500">Privacy Policy</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Anantapur, Andhra Pradesh
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                support@finddoctorsz.com
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                +91 XXXXX XXXXX
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Download App</h3>
            <div className="space-y-2">
              <button className="w-full px-4 py-2 bg-white text-gray-900 rounded flex items-center justify-center hover:bg-gray-100">
                <Download className="h-5 w-5 mr-2" />
                Google Play
              </button>
              <button className="w-full px-4 py-2 bg-white text-gray-900 rounded flex items-center justify-center hover:bg-gray-100">
                <Download className="h-5 w-5 mr-2" />
                App Store
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-800 text-center">
          <p>&copy; {new Date().getFullYear()} Finddoctorsz. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}