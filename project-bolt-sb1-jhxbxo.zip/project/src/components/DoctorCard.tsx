import React from 'react';
import { Phone, Mail, MapPin, Calendar } from 'lucide-react';
import { Doctor } from '../types/doctor';

interface DoctorCardProps {
  doctor: Doctor;
}

export default function DoctorCard({ doctor }: DoctorCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex items-start">
          {doctor.photoUrl && (
            <img
              src={doctor.photoUrl}
              alt={doctor.name}
              className="w-24 h-24 rounded-full object-cover mr-6"
            />
          )}
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-gray-900">{doctor.name}</h3>
            <p className="text-blue-600">{doctor.specialty}</p>
            <div className="mt-2 space-y-2 text-sm text-gray-600">
              <p className="flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                {doctor.location}
              </p>
              <p className="flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                Available: {doctor.availability.days.join(', ')}
              </p>
              <p className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                {doctor.contact.phone}
              </p>
              <p className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                {doctor.contact.email}
              </p>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
            Book Appointment
          </button>
        </div>
      </div>
    </div>
  );
}