export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  qualifications: string[];
  experience: number;
  location: string;
  availability: {
    days: string[];
    hours: string;
  };
  contact: {
    email: string;
    phone: string;
  };
  photoUrl?: string;
  bio: string;
}